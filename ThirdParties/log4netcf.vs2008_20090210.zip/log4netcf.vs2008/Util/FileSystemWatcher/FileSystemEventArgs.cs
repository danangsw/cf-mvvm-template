﻿#if NETCF
using System;
using System.IO;

namespace log4net.Util.FileSystemWatcher
{
    /// <summary>
    /// Changes that might occur to a file or directory. Based on: http://msdn.microsoft.com/en-us/library/t6xf43e0.aspx
    /// </summary>
    public enum WatcherChangeTypes
    {
        /// <summary>
        /// The creation, deletion, change, or renaming of a file or folder.
        /// </summary>
        All = 15,
        /// <summary>
        /// The change of a file or folder. The types of changes include: changes to size, attributes, security settings, last write, and last access time.
        /// </summary>
        Changed = 4,
        /// <summary>
        /// The creation of a file or folder.
        /// </summary>
        Created = 1,
        /// <summary>
        /// The deletion of a file or folder.
        /// </summary>
        Deleted = 2,
        /// <summary>
        /// The renaming of a file or folder.
        /// </summary>
        Renamed = 8
    }

    /// <summary>
    /// Provides data for the directory events: Changed, Created, Deleted. Based on: http://msdn.microsoft.com/en-us/library/system.io.filesystemeventargs.aspx
    /// </summary>
    /// <author>Lukasz Antoniak</author>
    public class FileSystemEventArgs : EventArgs
    {
        private WatcherChangeTypes changeType;
        private string fullPath;
        private string name;

        /// <summary>
        /// Initializes a new instance of the FileSystemEventArgs class.
        /// </summary>
        /// <param name="changeType">One of the WatcherChangeTypes values, which represents the kind of change detected in the file system.</param>
        /// <param name="directory">The root directory of the affected file or directory.</param>
        /// <param name="name">The name of the affected file or directory.</param>
        public FileSystemEventArgs(WatcherChangeTypes changeType, string directory, string name)
        {
            this.changeType = changeType;
            this.name = name;
            fullPath = (directory.EndsWith(Path.DirectorySeparatorChar.ToString())) ?
                directory + name : directory + Path.DirectorySeparatorChar + name;
        }

        /// <summary>
        /// Gets the type of directory event that occurred.
        /// </summary>
        public WatcherChangeTypes ChangeType
        {
            get
            {
                return changeType;
            }
        }

        /// <summary>
        /// Gets the fully qualifed path of the affected file or directory.
        /// </summary>
        public string FullPath
        {
            get
            {
                return fullPath;
            }
        }

        /// <summary>
        /// Gets the name of the affected file or directory.
        /// </summary>
        public string Name
        {
            get
            {
                return name;
            }
        }
    }
}
#endif
