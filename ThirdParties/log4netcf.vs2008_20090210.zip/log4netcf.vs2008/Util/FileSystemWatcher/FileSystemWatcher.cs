﻿#if NETCF
using System;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.WindowsCE.Forms;
using System.IO;

namespace log4net.Util.FileSystemWatcher
{
    /// <summary>
    /// Specifies changes to watch for in a file or folder. Based on: http://msdn.microsoft.com/en-us/library/system.io.notifyfilters.aspx
    /// </summary>
    /// <remarks>You can combine the members of this enumeration to watch for more than one kind of change. For example, you can watch for changes in the size of a file or folder, and for changes in security settings. This raises an event anytime there is a change in size or security settings of a file or folder.</remarks>
    /// <seealso cref="FileSystemWatcher"/>
    /// <seealso cref="FileSystemEventArgs"/>
    /// <seealso cref="FileSystemEventHandler"/>
    /// <seealso cref="RenamedEventArgs"/>
    /// <seealso cref="RenamedEventHandler"/>
    /// <seealso cref="WatcherChangeTypes"/>
    public enum NotifyFilters
    {
        /// <summary>
        /// The attributes of the file or folder.
        /// </summary>
        Attributes = 4,
        /// <summary>
        /// The time the file or folder was created.
        /// </summary>
        CreationTime = 0x40,
        /// <summary>
        /// The name of the directory.
        /// </summary>
        DirectoryName = 2,
        /// <summary>
        /// The name of the file.
        /// </summary>
        FileName = 1,
        /// <summary>
        /// The date the file or folder was last opened.
        /// </summary>
        LastAccess = 0x20,
        /// <summary>
        /// The date the file or folder last had anything written to it.
        /// </summary>
        LastWrite = 0x10,
        /// <summary>
        /// The security settings of the file or folder.
        /// </summary>
        Security = 0x100,
        /// <summary>
        /// The size of the file or folder.
        /// </summary>
        Size = 8
    }

    /// <summary>
    /// Represents the method that will handle the Changed, Created, or Deleted event of a FileSystemWatcher class. http://msdn.microsoft.com/en-us/library/system.io.filesystemeventhandler.aspx
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The FileSystemEventArgs that contains the event data.</param>
    public delegate void FileSystemEventHandler(object sender, FileSystemEventArgs e);

    /// <summary>
    /// Represents the method that will handle the Renamed event of a FileSystemWatcher class. Based on: http://msdn.microsoft.com/en-us/library/system.io.renamedeventhandler.aspx
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The RenamedEventArgs that contains the event data.</param>
    public delegate void RenamedEventHandler(object sender, RenamedEventArgs e);

    /// <summary>
    /// Listens to the file system change notifications and raises events when a directory, or file in a directory, changes.  Based on: http://msdn.microsoft.com/en-us/library/system.io.filesystemwatcher.aspx
    /// </summary>
    /// <author>Lukasz Antoniak</author>
    public class FileSystemWatcher : IDisposable
    {
        /// <summary>
        /// The default filter string.
        /// </summary>
        public static readonly string DEFAULT_FILTER = "*.*";

        /// <summary>
        /// The default (root) path.
        /// </summary>
        public static readonly string DEFAULT_PATH = @"\";

        private ReceiverWindow msgWindow = null;
        private string path = "";
        private string filter = "";
        private bool enableRaisingEvents = false;
        private bool recursive = false;

        internal IntPtr fileNameUnmanagedPtr;

        private NotifyFilters notifyFilter = NotifyFilters.LastWrite | NotifyFilters.DirectoryName | NotifyFilters.FileName;

        /// <summary>
        /// Occurs when a file or directory in the specified Path is created.
        /// </summary>
        public event FileSystemEventHandler Created;

        /// <summary>
        /// Occurs when a file or directory in the specified Path is changed.
        /// </summary>
        public event FileSystemEventHandler Changed;

        /// <summary>
        /// Occurs when a file or directory in the specified Path is deleted.
        /// </summary>
        public event FileSystemEventHandler Deleted;

        /// <summary>
        /// Occurs when a file or directory in the specified Path is renamed.
        /// </summary>
        public event RenamedEventHandler Renamed;

        /// <summary>
        /// Initializes a new instance of the FileSystemWatcher class. Sets the path attribute to DEFAULT_PATH value and filter to DEFAULT_FILTER.
        /// </summary>
        public FileSystemWatcher() : this(DEFAULT_PATH)
        {
        }

        /// <summary>
        /// Initializes a new instance of the FileSystemWatcher class, given the specified directory to monitor. Sets the filter attribute to DEFAULT_FILTER.
        /// </summary>
        /// <param name="path"></param>
        public FileSystemWatcher(string path) : this(path, DEFAULT_FILTER)
        {
        }

        /// <summary>
        /// Initializes a new instance of the FileSystemWatcher class, given the specified directory and type of files to monitor.
        /// </summary>
        /// <param name="path">The directory to monitor, in standard or Universal Naming Convention (UNC) notation.</param>
        /// <param name="filter">The type of files to watch. For example, "*.txt" watches for changes to all text files.</param>
        /// <exception cref="ArgumentException">Exception occurs when path argument is null or directory could not be found.</exception>
        public FileSystemWatcher(string path, string filter)
        {
            if (path == null || !Directory.Exists(path))
            {
                throw new ArgumentException("Error: Could not find directory: " + path + ".");
            }
            Path = path;
            Filter = filter;
            msgWindow = new ReceiverWindow(this);
        }

        /// <summary>
        /// Deregisters the file system watching mechanism and removes the object instance.
        /// </summary>
        public void Dispose()
        {
            deregister();
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Registers the file system watching mechanism.
        /// </summary>
        /// <exception cref="Exception">Exception occurs when ReceiverWindow.SHChangeNotifyRegister method does not succeed.</exception>
        internal void register()
        {
            ReceiverWindow.SHCHANGENOTIFYENTRY shChangeNotifyEntry = new ReceiverWindow.SHCHANGENOTIFYENTRY();
            shChangeNotifyEntry.dwEventMask = ReceiverWindow.SHCNE_ALLEVENTS;
            shChangeNotifyEntry.fRecursive = (recursive) ? 1 : 0;
            fileNameUnmanagedPtr = StringToInPtrUnicode(path);
            shChangeNotifyEntry.pszWatchDir = fileNameUnmanagedPtr;
//            Works only in .NET CF 2.0
//            shChangeNotifyEntry.pszWatchDir = Marshal.StringToBSTR(path);
            int result = ReceiverWindow.SHChangeNotifyRegister(msgWindow.Hwnd, ref shChangeNotifyEntry);
            if (result != 1)
            {
                throw new Exception("Error: Could not register SHChangeNotifyRegister.");
            }
        }

        internal static IntPtr StringToInPtrUnicode(string s)
        {
            if (s == null)
            {
                return IntPtr.Zero;
            }
            byte[] bytes = Encoding.Unicode.GetBytes(s + '\0');
            IntPtr ptr = Marshal.AllocHGlobal(bytes.Length);
            Marshal.Copy(bytes, 0, ptr, bytes.Length);
            return ptr;
        }

        /// <summary>
        /// Deregisters file system watching mechanism.
        /// </summary>
        internal void deregister()
        {
            Marshal.FreeHGlobal(fileNameUnmanagedPtr);
            ReceiverWindow.SHChangeNotifyDeregister(msgWindow.Hwnd);
        }

        /// <summary>
        /// Checks whether file that has been changed, created or deleted sutisfies previousely set filter.
        /// </summary>
        /// <param name="fileName">The file name received from event.</param>
        /// <returns>True if file name satisfies filter.</returns>
        private bool validateFilter(string fileName)
        {
            if (filter == DEFAULT_FILTER)
            {
                return true;
            }
            if (filter == fileName)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Raises the Changed event.
        /// </summary>
        /// <param name="e">A FileSystemEventArgs that contains the event data.</param>
        public virtual void OnChanged(FileSystemEventArgs e)
        {
            lock (this)
            {
                if (Changed != null)
                {
                    Changed(this, e);
                }
            }
        }

        /// <summary>
        /// Raises the Created event.
        /// </summary>
        /// <param name="e">A FileSystemEventArgs that contains the event data.</param>
        public virtual void OnCreated(FileSystemEventArgs e)
        {
            lock (this)
            {
                if (Created != null)
                {
                    Created(this, e);
                }
            }
        }

        /// <summary>
        /// Raises the Deleted event.
        /// </summary>
        /// <param name="e">A FileSystemEventArgs that contains the event data.</param>
        public virtual void OnDeleted(FileSystemEventArgs e)
        {
            lock (this)
            {
                if (Deleted != null)
                {
                    Deleted(this, e);
                }
            }
        }

        /// <summary>
        /// Raises the Renamed event.
        /// </summary>
        /// <param name="e">A RenamedEventArgs that contains the event data.</param>
        public virtual void OnRenamed(RenamedEventArgs e)
        {
            lock (this)
            {
                if (Renamed != null)
                {
                    Renamed(this, e);
                }
            }
        }

        /// <summary>
        /// Sets the directory path to watch. Get returns the value.
        /// </summary>
        /// <exception cref="ArgumentException">Exception occurs when the value is null or directory does not exist.</exception>
        public string Path
        {
            get { return path; }
            set
            {
                if (value == null || !Directory.Exists(value))
                {
                    throw new ArgumentException("Error: Could not find directory: " + path + ".");
                }
                path = value;
            }
        }

        /// <summary>
        /// Sets the filter property. If the value is null or an empty string, filter is set to DEFAULT_FILTER. Get returns the value.
        /// </summary>
        public string Filter
        {
            get { return filter; }
            set
            {
                if (value == null || value == string.Empty)
                {
                    filter = DEFAULT_FILTER;
                }
                else
                {
                    filter = value;
                }
            }
        }

        /// <summary>
        /// Sets or gets the value of NotifyFilter.
        /// </summary>
        public NotifyFilters NotifyFilter
        {
            get { return notifyFilter; }
            set { notifyFilter = value; }
        }

        /// <summary>
        /// Sets or gets the EnableRaisingEvents property. If the setter modifies the initial value, raising events is registered or deregistered.
        /// </summary>
        public bool EnableRaisingEvents
        {
            get { return enableRaisingEvents; }
            set
            {
                if (enableRaisingEvents != value)
                {
                    if (value)
                    {
                        // If we want to activate raising events.
                        register();
                    }
                    else
                    {
                        deregister();
                    }
                    enableRaisingEvents = value;
                }
            }
        }

        /// <summary>
        /// Sets or gets IncludeSubdirectories property.
        /// </summary>
        public bool IncludeSubdirectories
        {
            get { return recursive; }
            set { recursive = value; }
        }

        /**
         * The MessageWindow class that receives events from native API.
         * See: http://msdn.microsoft.com/en-us/library/microsoft.windowsce.forms.messagewindow.aspx
         */
        internal class ReceiverWindow : MessageWindow
        {
            /**
             * Masks of event types.
             * See: http://msdn.microsoft.com/en-us/library/aa931819.aspx
             */
            internal const int SHCNE_RENAMEITEM = 0x00000001;         // The name of a non-folder item has changed.
            internal const int SHCNE_CREATE = 0x00000002;             // A non-folder item has been created.
            internal const int SHCNE_DELETE = 0x00000004;             // A non-folder item has been deleted.
            internal const int SHCNE_ALLEVENTS = 0x7FFFFFFF;          // Use this to request notification for all events.
            internal const int SHCNE_UPDATEITEM = 0x00002000;         // A non-folder item has changed, but was not renamed or deleted.
//            internal const int SHCNE_MKDIR = 0x00000008;              // A folder has been created.
//            internal const int SHCNE_RMDIR = 0x00000010;              // A folder has been deleted.
//            internal const int SHCNE_MEDIAINSERTED = 0x00000020;      // Storage media has been inserted into a drive.
//            internal const int SHCNE_MEDIAREMOVED = 0x00000040;       // Storage media has been removed from a drive.
//            internal const int SHCNE_DRIVEREMOVED = 0x00000080;       // Not supported.
//            internal const int SHCNE_DRIVEADD = 0x00000100;           // Not supported.
//            internal const int SHCNE_NETSHARE = 0x00000200;           // A folder on the local device is being shared on the network.
//            internal const int SHCNE_NETUNSHARE = 0x00000400;         // A folder on the local device is no longer being shared on the network.
//            internal const int SHCNE_ATTRIBUTES = 0x00000800;         // The attributes of an item or folder have changed.
//            internal const int SHCNE_UPDATEDIR = 0x00001000;          // The contents of an existing folder have changed, but the folder was not renamed or deleted.
//            internal const int SHCNE_SERVERDISCONNECT = 0x00004000;   // Not supported.
//            internal const int SHCNE_RENAMEFOLDER = 0x00020000;       // The name of a folder has changed.

            internal const int WM_FILECHANGEINFO = 0x8101;

            /**
             * The basic file change notification structure.
             * See: http://msdn.microsoft.com/en-us/library/aa929104.aspx
             */
            internal struct FILECHANGENOTIFY
            {
                internal int dwRefCount;
                internal FILECHANGEINFO fci;
            }

            /**
             * The basic file change info structure.
             * See: http://msdn.microsoft.com/en-us/library/aa916006.aspx
             */
            internal struct FILECHANGEINFO
            {
                internal int cbSize;
                internal int wEventId;
                internal uint uFlags;
                internal int dwItem1;
                internal int dwItem2;
                internal int dwAttributes;
                internal int dwLowDateTime;
                internal int dwHighDateTime;
                internal uint nFileSize;
            }

            /**
             * Method registers file system watcher notification.
             * See: http://msdn.microsoft.com/en-us/library/aa932924.aspx
             */
            [DllImport("aygshell.dll")]
            internal static extern int SHChangeNotifyRegister(
                IntPtr hwnd,
                ref SHCHANGENOTIFYENTRY pshcne);

            /**
             * Method frees file system watcher notification.
             * See: http://msdn.microsoft.com/en-us/library/aa932772.aspx
             */
            [DllImport("aygshell.dll")]
            internal static extern void SHChangeNotifyFree(IntPtr pshcne);

            /**
             * Method deregisters file system watcher notification.
             * See: http://msdn.microsoft.com/en-us/library/aa933022.aspx
             */
            [DllImport("aygshell.dll")]
            internal static extern int SHChangeNotifyDeregister(
                IntPtr hwnd);

            /**
             * The basic file change notification entry structure.
             * See: http://msdn.microsoft.com/en-us/library/aa931819.aspx
             */
            internal struct SHCHANGENOTIFYENTRY
            {
                internal int dwEventMask;
                internal IntPtr pszWatchDir;
                internal int fRecursive;
            }

            private FileSystemWatcher fileSystemWatcher = null;

            /// <summary>
            /// Initializes a new instance of the ReceiverWindow class.
            /// </summary>
            /// <param name="fsw">The file system watcher class that provides event raising in managed code..</param>
            public ReceiverWindow(FileSystemWatcher fsw)
            {
                fileSystemWatcher = fsw;
            }

            /// <summary>
            /// The overrided method that receives events from native API. Checks whether the file that has been modified fullfills filter property value.
            /// </summary>
            /// <param name="msg"></param>
            protected override void WndProc(ref Message msg)
            {
                if (msg.Msg == WM_FILECHANGEINFO && msg.LParam != IntPtr.Zero)
                {
                    FILECHANGENOTIFY fileChangeNotify = (FILECHANGENOTIFY)Marshal.PtrToStructure(msg.LParam, typeof(FILECHANGENOTIFY));
                    string absolutePath = Marshal.PtrToStringUni((IntPtr)fileChangeNotify.fci.dwItem1);
                    string fileName = System.IO.Path.GetFileName(absolutePath);
                    string dirName = System.IO.Path.GetDirectoryName(absolutePath);

//                    /* For debug purpose. */
//                    string msgCode = Convert.ToString(msg.Msg, 16);
//                    string eventCode = Convert.ToString(fileChangeNotify.fci.wEventId, 16);

                    if (fileSystemWatcher.validateFilter(fileName))
                    {
                        switch (fileChangeNotify.fci.wEventId)
                        {
                            case SHCNE_CREATE:
                                if ((fileSystemWatcher.NotifyFilter & NotifyFilters.FileName) == NotifyFilters.FileName)
                                {
                                    fileSystemWatcher.OnCreated(
                                        new FileSystemEventArgs(WatcherChangeTypes.Created, dirName, fileName));
                                }
                                break;
                            case SHCNE_UPDATEITEM:
                                if ((fileSystemWatcher.NotifyFilter & NotifyFilters.FileName) == NotifyFilters.FileName)
                                {
                                    fileSystemWatcher.OnChanged(
                                        new FileSystemEventArgs(WatcherChangeTypes.Changed, dirName, fileName));
                                }
                                break;
                            case SHCNE_DELETE:
                                if ((fileSystemWatcher.NotifyFilter & NotifyFilters.FileName) == NotifyFilters.FileName)
                                {
                                    fileSystemWatcher.OnDeleted(
                                        new FileSystemEventArgs(WatcherChangeTypes.Deleted, dirName, fileName));
                                }
                                break;
                            case SHCNE_RENAMEITEM:
                                if ((fileSystemWatcher.NotifyFilter & NotifyFilters.FileName) == NotifyFilters.FileName)
                                {
                                    string newFileAbsolutePath =
                                        Marshal.PtrToStringUni((IntPtr)fileChangeNotify.fci.dwItem2);
                                    fileSystemWatcher.OnRenamed(
                                        new RenamedEventArgs(WatcherChangeTypes.Renamed, dirName,
                                                             System.IO.Path.GetFileName(newFileAbsolutePath), fileName));
                                }
                                break;
                        }
                    }

                    SHChangeNotifyFree(msg.LParam);
                }

                msg.Result = IntPtr.Zero;
                base.WndProc(ref msg);
            }
        }
    }
}
#endif
