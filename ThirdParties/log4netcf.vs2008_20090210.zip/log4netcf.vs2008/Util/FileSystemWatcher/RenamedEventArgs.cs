﻿#if NETCF
using System.IO;

namespace log4net.Util.FileSystemWatcher
{
    /// <summary>
    /// Provides data for the Renamed event. Based on: http://msdn.microsoft.com/en-us/library/system.io.renamedeventargs.aspx
    /// </summary>
    /// <author>Lukasz Antoniak</author>
    public class RenamedEventArgs : FileSystemEventArgs
    {
        private string oldFullPath;
        private string oldName;

        /// <summary>
        /// Initializes a new instance of the RenamedEventArgs class.
        /// </summary>
        /// <param name="changeType">One of the WatcherChangeTypes values.</param>
        /// <param name="directory">The name of the affected file or directory.</param>
        /// <param name="name">The name of the affected file or directory.</param>
        /// <param name="oldName">The old name of the affected file or directory.</param>
        public RenamedEventArgs(WatcherChangeTypes changeType, string directory, string name, string oldName)
            : base(changeType, directory, name)
        {
            this.oldName = oldName;
            oldFullPath = (directory.EndsWith(Path.DirectorySeparatorChar.ToString())) ?
                directory + oldName : directory + Path.DirectorySeparatorChar + oldName;
        }

        /// <summary>
        /// Gets the previous fully qualified path of the affected file or directory.
        /// </summary>
        public string OldFullPath
        {
            get
            {
                return oldFullPath;
            }
        }

        /// <summary>
        /// Gets the old name of the affected file or directory.
        /// </summary>
        public string OldName
        {
            get
            {
                return oldName;
            }
        }
    }
}
#endif
